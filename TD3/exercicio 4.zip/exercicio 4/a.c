#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define MAXTXT     4096
#define MAXCHOICE  10

typedef enum { NORMAL, WON, FAILED } TipoCena;

typedef struct Cena {
    char *descritivo;
    TipoCena tipo;
    int nopcoes;
    char **vopcoes;
} Cena;

typedef struct no {
    Cena *cena;
    struct no **vizinhos;
    int nvizinhos;
} No;

typedef struct historia {
    No *cena_inicial;
    No *cena_ativa;
    No **nos;
    Cena **cenas;
    int n;
} Historia;

Cena *criaCena(char *descritivo, TipoCena tipo, int nopcoes, char **vopcoes) {
    // Verifica se o número de opções é válido
    if ((tipo == NORMAL && nopcoes <= 0) || (tipo != NORMAL && nopcoes != 0)) {
        #ifdef DEBUG
        errno = EINVAL; // Define o erro como argumento inválido
        perror("Erro: Cena de tipo NORMAL deve ter pelo menos uma opção.\n");
        #endif
        return NULL; // Retorna NULL em caso de erro
    }

    // Aloca memória para a nova cena
    Cena *novaCena = (Cena *)malloc(sizeof(Cena));
    if (novaCena == NULL) {
        #ifdef DEBUG
        errno = ENOMEM; // Define o erro como falta de memória
        perror("Erro: Falha ao alocar memória para a nova cena.\n");
        #endif
        return NULL; // Retorna NULL se a alocação falhar
    }

    // Preenche os campos da nova cena
    novaCena->tipo = tipo;
    novaCena->nopcoes = nopcoes;
    novaCena->descritivo = (char *)malloc(sizeof(char) * MAXTXT);
    
    if (novaCena->descritivo == NULL) {
        #ifdef DEBUG
        errno = ENOMEM; // Define o erro como falta de memória
        perror("Erro: Falha ao alocar memória para o descritivo.\n");
        #endif
        free(novaCena);
        return NULL; // Retorna NULL se a alocação falhar
    }
    strcpy(novaCena->descritivo, descritivo);

    // Verificar se vopcoes é NULL quando necessário
    if (tipo == NORMAL && (nopcoes <= 0 || vopcoes == NULL)) {
        #ifdef DEBUG
        errno = EINVAL;
        perror("Erro: Cena de tipo NORMAL deve ter opções válidas.\n");
        #endif
        return NULL;
    }

    // Aloca memória para as opções de continuação
    novaCena->vopcoes = (char **)malloc(nopcoes * sizeof(char *));
    if (novaCena->vopcoes == NULL) {
        #ifdef DEBUG
        errno = ENOMEM; // Define o erro como falta de memória
        perror("Erro: Falha ao alocar memória para as opções.\n");
        #endif
        free(novaCena->descritivo);
        free(novaCena);
        return NULL; // Retorna NULL se a alocação falhar
    }

    // Preenche as opções de continuação
    for (int i = 0; i < nopcoes; i++) {
        novaCena->vopcoes[i] = (char *)malloc(strlen(vopcoes[i]) + 1);
        if (novaCena->vopcoes[i] == NULL) {
            for (int j = 0; j < i; j++) {
                free(novaCena->vopcoes[j]);
            }
            free(novaCena->vopcoes);
            free(novaCena->descritivo);
            free(novaCena);
            return NULL; // Retorna NULL se a alocação falhar
        }
        strcpy(novaCena->vopcoes[i], vopcoes[i]);
    }

    return novaCena; // Retorna o apontador para a nova cena criada
}

/*
que imprime na saída standard o conteúdo da cena c , à semelhança dos
exemplos acima descritos. As opções consideradas são sempre numeradas 'a' ,
'b' , 'c' etc...
*/
void mostrarCena(Cena *c) {
    if (c == NULL) {
        #ifdef DEBUG
        errno = EINVAL; // Define o erro como argumento inválido
        perror("Erro: Cena inválida.\n");
        #endif
        return;
    }

    // Formato: [ID] (ID não está na estrutura, omitido aqui)
    printf("<<<\n%s\n>>>", c->descritivo);
    
    // Adicionar tipo/número de opções
    if (c->tipo == NORMAL) {
        printf("<%d>\n", c->nopcoes);
        printf("***\n");
        for (int i = 0; i < c->nopcoes; i++) {
            printf("+ %c. %s\n", 'a' + i, c->vopcoes[i]);
        }
        printf("***\n");
    } else {
        printf("<%s>\n", (c->tipo == WON) ? "WON" : "FAILED");
        printf("***\n");
    }
}
/*
que liberta a memória apontada por c assim como a dos seus campos.
*/
void libertaCena(Cena *c) {
    if (c == NULL) {
        #ifdef DEBUG
        errno = EINVAL; // Define o erro como argumento inválido
        perror("Erro: Cena inválida.\n");
        #endif
        return; // Verifica se a cena é válida
    }

    free(c->descritivo); // Libera a memória da descritivo
    for (int i = 0; i < c->nopcoes; i++) {
        free(c->vopcoes[i]); // Libera a memória de cada opção
    }
    free(c->vopcoes); // Libera a memória do vetor de opções
    free(c); // Libera a memória da cena
}

/*
que cria um nó com o conteúdo a apontar para a cena que está no endereço c e
que terá nvizinhos vizinhos. As células do vetor de vizinhos é inicializado,
nesta função, com o valor NULL 
*/
No *criaNo(Cena *c, int nvizinhos){
    if (c == NULL || nvizinhos < 0 || (c->tipo == NORMAL && nvizinhos != c->nopcoes)) {
        #ifdef DEBUG
        errno = EINVAL;
        perror("Erro: Parâmetros inválidos para criar nó.\n");
        #endif
        return NULL;
    }

    No *novoNo = (No *)malloc(sizeof(No));
    if (novoNo == NULL) {
        #ifdef DEBUG
        errno = ENOMEM; // Define o erro como falta de memória
        perror("Erro: Falha ao alocar memória para o novo nó.\n");
        #endif
        return NULL; // Retorna NULL se a alocação falhar
    }

    novoNo->cena = c;
    novoNo->nvizinhos = nvizinhos;
    novoNo->vizinhos = (No **)malloc(nvizinhos * sizeof(No *));
    
    if (novoNo->vizinhos == NULL) {
        free(novoNo);
        #ifdef DEBUG
        errno = ENOMEM; // Define o erro como falta de memória
        perror("Erro: Falha ao alocar memória para os vizinhos do nó.\n");
        #endif
        return NULL; // Retorna NULL se a alocação falhar
    }

    for (int i = 0; i < nvizinhos; i++) {
        novoNo->vizinhos[i] = NULL; // Inicializa os vizinhos com NULL
    }

    return novoNo; // Retorna o apontador para o novo nó criado
}

/*
que coloca a posição pos do vetor de vizinhos do nó no a apontar para v 
*/
void juntaVizinhoNo(No *no, int pos, No* v){
    if (no == NULL || pos < 0 || pos >= no->nvizinhos) {
        #ifdef DEBUG
        errno = EINVAL; // Define o erro como argumento inválido
        perror("Erro: Nó inválido ou posição inválida.\n");
        #endif
        return; // Retorna se o nó ou a posição forem inválidos
    }

    no->vizinhos[pos] = v; // Junta o vizinho na posição especificada
}

/*
que devolve a referência do nó que corresponde à escolha escolha tendo em
conta às opções possíveis propostas pela cena contida no no_ativo . Em caso de
anomalia (como o de uma escolha inválida), o programa deverá reagir de forma
adequada, garantindo a robustez da execução.
*/
No *proximoNo(No *no_ativo, int escolha) {
    if (no_ativo == NULL || no_ativo->cena == NULL || no_ativo->nvizinhos != no_ativo->cena->nopcoes) {
        #ifdef DEBUG
        errno = EINVAL;
        perror("Erro: Nó ativo inválido ou inconsistência entre opções e vizinhos.\n");
        #endif
        return NULL;
    }
    if (escolha < 0 || escolha >= no_ativo->nvizinhos) {
        #ifdef DEBUG
        errno = EINVAL;
        perror("Erro: Escolha inválida.\n");
        #endif
        return NULL;
    }
    return no_ativo->vizinhos[escolha];
}


//Mostra a informação da cena (o seu descritivo, etc.) contida no nó no .
void mostraCenaNo(No *no){
    if (no == NULL) {
        #ifdef DEBUG
        errno = EINVAL; // Define o erro como argumento inválido
        perror("Erro: Nó inválido.\n");
        #endif
        return; // Retorna se o nó for inválido
    }

    mostrarCena(no->cena); // Mostra a cena contida no nó
}

/*
Que informa do tipo de cena contida no nó no .
*/
TipoCena estadoCenaNo(No *no) {
    if (no == NULL || no->cena == NULL) {
        #ifdef DEBUG
        errno = EINVAL;
        perror("Erro: Nó inválido.\n");
        #endif
        return FAILED; // Valor padrão em caso de erro
    }
    return no->cena->tipo;
}

/*
Que permite ao utilizador escolher uma opção dentro das possíveis na
cena contida no nó no 
*/
int escolheCenaNo(No *no){
    if (no == NULL) {
        #ifdef DEBUG
        errno = EINVAL; // Define o erro como argumento inválido
        perror("Erro: Nó inválido.\n");
        #endif
        return -1; // Retorna -1 se o nó for inválido
    }

    int escolha;
    printf("Escolha uma opção (0-%d): ", no->cena->nopcoes - 1);
    scanf("%d", &escolha);

    if (escolha < 0 || escolha >= no->cena->nopcoes) {
        #ifdef DEBUG
        errno = EINVAL; // Define o erro como argumento inválido
        perror("Erro: Escolha inválida.\n");
        #endif
        return -1; // Retorna -1 se a escolha for inválida
    }

    return escolha; // Retorna a escolha válida do usuário
}

/* Lê uma linha inteira até '\n', retornando string alocada */
static char *read_line(void) {
    char buf[MAXTXT];
    if (!fgets(buf, sizeof(buf), stdin))
        return NULL;
    size_t len = strlen(buf);
    if (len && buf[len-1]=='\n') buf[--len] = '\0';
    char *s = malloc(len+1);
    if (s) strcpy(s, buf);
    return s;
}

/* Cria a história lendo de stdin e montando o grafo */
Historia *criaHistoria(void) {
    int n;
    if (scanf("%d\n", &n) != 1 || n <= 0) {
        fprintf(stderr, "Input inválido: número de cenas\n");
        return NULL;
    }

    /* Aloca arrays de ponteiros */
    Cena **cenas = malloc(n * sizeof(Cena*));
    No   **nos   = malloc(n * sizeof(No*));
    int     targets[n][MAXCHOICE];
    char   *vopts[n][MAXCHOICE];

    for (int i = 0; i < n; i++) {
        char *lin = read_line(); free(lin); // "[i]"
        lin = read_line(); free(lin);       // "<<<"

        /* Lê descritivo até ">>>" */
        char desc[MAXTXT] = "";
        while (1) {
            lin = read_line();
            if (!lin) break;
            if (strcmp(lin, ">>>") == 0) { free(lin); break; }
            strncat(desc, lin, sizeof(desc)-strlen(desc)-2);
            strncat(desc, "\n", sizeof(desc)-strlen(desc)-1);
            free(lin);
        }

        /* Analisa linha com tipo e número de opções */
        lin = read_line();
        TipoCena tipo;
        int nopcoes;
        if (sscanf(lin, ">>><%d>", &nopcoes) == 1) {
            tipo = NORMAL;
        } else if (strstr(lin, "WON")) {
            tipo = WON; nopcoes = 0;
        } else {
            tipo = FAILED; nopcoes = 0;
        }
        free(lin);

        /* Se for NORMAL, lê opções entre "***" */
        if (tipo == NORMAL) {
            lin = read_line(); free(lin); // "***"
            for (int j = 0; j < nopcoes; j++) {
                lin = read_line();
                int tgt;
                char txt[MAXTXT];
                if (sscanf(lin, "+ %d. %[^
]", &tgt, txt) != 2) {
                    fprintf(stderr, "Formato de opção inválido na cena %d\n", i);
                    exit(1);
                }
                targets[i][j] = tgt;
                vopts[i][j] = strdup(txt);
                free(lin);
            }
            lin = read_line(); free(lin); // "***"
        }

        /* Cria cena e nó correspondentes */
        cenas[i] = criaCena(desc, tipo, nopcoes,
                            (tipo==NORMAL ? vopts[i] : NULL));
        nos[i]   = criaNo(cenas[i], (tipo==NORMAL? nopcoes: 0));
    }

    /* Liga vizinhos conforme targets */
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < nos[i]->nvizinhos; j++) {
            int tgt = targets[i][j];
            juntaVizinhoNo(nos[i], j, nos[tgt]);
        }
    }

    Historia *hist = malloc(sizeof(Historia));
    hist->cena_inicial = hist->cena_ativa = nos[0];
    hist->nos   = nos;
    hist->cenas = cenas;
    hist->n     = n;
    return hist;
}

int main(void) {
    Historia *h = criaHistoria();
    if (!h) return 1;

    /* Simula a história até estado terminal */
    while (1) {
        TipoCena estado = estadoCenaNo(h->cena_ativa);
        if (estado == WON) {
            printf("WON\n"); break;
        } else if (estado == FAILED) {
            printf("FAILED\n"); break;
        }
        int escolha = escolheCenaNo(h->cena_ativa);
        if (escolha < 0) {
            printf("WAITING\n"); break;
        }
        No *prox = proximoNo(h->cena_ativa, escolha);
        if (!prox) {
            printf("WAITING\n"); break;
        }
        h->cena_ativa = prox;
    }

    /* Liberta memória de nós e cenas */
    for (int i = 0; i < h->n; i++) {
        free(h->nos[i]->vizinhos);
        free(h->nos[i]);
        libertaCena(h->cenas[i]);
    }
    free(h->nos);
    free(h->cenas);
    free(h);
    return 0;
}
